import React, { useState, useEffect, useRef } from 'react';
import {
  SafeAreaView,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  StatusBar,
  Modal,
  KeyboardAvoidingView,
  Platform,
  Vibration,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

// ==========================================
// LOCAL STORAGE DATABASE KEYS
// ==========================================
const DB_KEYS = {
  PROFILES: '@speedmath_db_profiles_v1',
  ACTIVE_PROFILE_ID: '@speedmath_db_active_profile_v1',
  ATTEMPTS: '@speedmath_db_attempts_v1',
  THEME: '@speedmath_db_theme_v1',
};

// ==========================================
// DATA MODELS & TYPES
// ==========================================
export type CategoryId = 'multiplication' | 'squares' | 'cubes' | 'perc_frac';

export interface CategoryRanges {
  multiplication: { from: number; to: number; m: number };
  squares: { from: number; to: number };
  cubes: { from: number; to: number };
  perc_frac: { from: number; to: number };
}

export interface QuestionItem {
  id: string;
  category: CategoryId;
  subPrompt: string;
  prompt: string;
  expectedType: 'integer' | 'percentage' | 'fraction';
  exactValue?: number;
  numerator?: number;
  denominator?: number;
  displayAnswer: string;
  explanation: string;
  hint: string;
  userAnswer: string;
  isCorrect: boolean;
  skipped: boolean;
  answered: boolean;
}

export interface UserProfile {
  id: string;
  name: string;
  avatarColor: string;
  createdAt: string;
}

export interface QuizAttempt {
  id: string;
  profileId: string;
  profileName: string;
  timestamp: string;
  modeLabel: string; // e.g., "Standard Drill", "Reattempt (Exact Questions)", "Reattempt (Wrong Only)"
  parentAttemptId?: string;
  ranges: CategoryRanges;
  selectedCategories: CategoryId[];
  totalQuestions: number;
  attemptedCount: number;
  correctCount: number;
  wrongCount: number;
  skippedCount: number;
  accuracy: number;
  elapsedSeconds: number;
  questions: QuestionItem[];
}

const CATEGORIES_META: Record<
  CategoryId,
  { id: CategoryId; name: string; shortBadge: string; accentColor: string }
> = {
  multiplication: {
    id: 'multiplication',
    name: 'Multiplication Table',
    shortBadge: 'Multiplication',
    accentColor: '#3b82f6',
  },
  squares: {
    id: 'squares',
    name: 'Squares (n²)',
    shortBadge: 'Squares (n²)',
    accentColor: '#a855f7',
  },
  cubes: {
    id: 'cubes',
    name: 'Cubes (n³)',
    shortBadge: 'Cubes (n³)',
    accentColor: '#f59e0b',
  },
  perc_frac: {
    id: 'perc_frac',
    name: 'Percentage ↔ Fraction',
    shortBadge: 'Pct ↔ Frac',
    accentColor: '#10b981',
  },
};

const AVATAR_COLORS = ['#4f46e5', '#0891b2', '#059669', '#d97706', '#e11d48', '#7c3aed'];

// ==========================================
// MATH ENGINE & HELPERS
// ==========================================
function gcd(a: number, b: number): number {
  let x = Math.abs(a);
  let y = Math.abs(b);
  while (y) {
    const t = y;
    y = x % y;
    x = t;
  }
  return x || 1;
}

function getMixedFractionPercentage(k: number): string {
  const whole = Math.floor(100 / k);
  const rem = 100 % k;
  if (rem === 0) return `${whole}%`;
  const g = gcd(rem, k);
  return `${whole} ${rem / g}/${k / g}%`;
}

function shuffleArray<T>(arr: T[]): T[] {
  const copy = [...arr];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

function buildCategoryPool(category: CategoryId, ranges: CategoryRanges): QuestionItem[] {
  const pool: QuestionItem[] = [];

  if (category === 'multiplication') {
    const { from, to, m } = ranges.multiplication;
    const startB = m >= 2 ? 2 : 1;
    for (let a = from; a <= to; a++) {
      for (let b = startB; b <= m; b++) {
        pool.push({
          id: `mult_${a}_${b}_${Math.random().toString(36).slice(2, 7)}`,
          category: 'multiplication',
          subPrompt: `Multiplication Table (${from}–${to} × up to ${m})`,
          prompt: `${a} × ${b} = ?`,
          expectedType: 'integer',
          exactValue: a * b,
          displayAnswer: `${a * b}`,
          explanation: `${a} × ${b} = ${a * b}`,
          hint: 'Type the exact product and tap Submit.',
          userAnswer: '',
          isCorrect: false,
          skipped: false,
          answered: false,
        });
      }
    }
  } else if (category === 'squares') {
    const { from, to } = ranges.squares;
    for (let x = from; x <= to; x++) {
      pool.push({
        id: `sq_${x}_${Math.random().toString(36).slice(2, 7)}`,
        category: 'squares',
        subPrompt: `Square of a Number (${from}² to ${to}²)`,
        prompt: `${x}² = ?`,
        expectedType: 'integer',
        exactValue: x * x,
        displayAnswer: `${x * x}`,
        explanation: `${x}² = ${x} × ${x} = ${x * x}`,
        hint: 'Type the exact square value and tap Submit.',
        userAnswer: '',
        isCorrect: false,
        skipped: false,
        answered: false,
      });
    }
  } else if (category === 'cubes') {
    const { from, to } = ranges.cubes;
    for (let x = from; x <= to; x++) {
      pool.push({
        id: `cube_${x}_${Math.random().toString(36).slice(2, 7)}`,
        category: 'cubes',
        subPrompt: `Cube of a Number (${from}³ to ${to}³)`,
        prompt: `${x}³ = ?`,
        expectedType: 'integer',
        exactValue: x * x * x,
        displayAnswer: `${x * x * x}`,
        explanation: `${x}³ = ${x} × ${x} × ${x} = ${x * x * x}`,
        hint: 'Type the exact cube value and tap Submit.',
        userAnswer: '',
        isCorrect: false,
        skipped: false,
        answered: false,
      });
    }
  } else if (category === 'perc_frac') {
    const { from, to } = ranges.perc_frac;
    for (let k = from; k <= to; k++) {
      const exactPct = 100 / k;
      const roundedPctStr = parseFloat(exactPct.toFixed(2)).toString();
      const mixedStr = getMixedFractionPercentage(k);
      const isExactInteger = 100 % k === 0;

      pool.push({
        id: `pf_pct_${k}_${Math.random().toString(36).slice(2, 7)}`,
        category: 'perc_frac',
        subPrompt: `Convert Fraction to Percentage (1/${from} to 1/${to})`,
        prompt: `1/${k} = ____ %`,
        expectedType: 'percentage',
        denominator: k,
        exactValue: exactPct,
        displayAnswer: isExactInteger ? `${roundedPctStr}%` : `${roundedPctStr}% (or ${mixedStr})`,
        explanation: `1/${k} × 100% = ${isExactInteger ? roundedPctStr + '%' : roundedPctStr + '% (' + mixedStr + ')'}`,
        hint: 'Enter percentage (e.g. 16.67 or 16 2/3). Standard 2-decimal rounding is accepted.',
        userAnswer: '',
        isCorrect: false,
        skipped: false,
        answered: false,
      });

      const promptLabel = isExactInteger
        ? `${roundedPctStr}% = ? (in fraction)`
        : `${roundedPctStr}% (${mixedStr}) = ?`;

      pool.push({
        id: `pf_frac_${k}_${Math.random().toString(36).slice(2, 7)}`,
        category: 'perc_frac',
        subPrompt: `Convert Percentage to Fraction (1/${from} to 1/${to})`,
        prompt: promptLabel,
        expectedType: 'fraction',
        numerator: 1,
        denominator: k,
        displayAnswer: `1/${k}`,
        explanation: `${isExactInteger ? roundedPctStr + '%' : roundedPctStr + '% (' + mixedStr + ')'} = 1/${k}`,
        hint: 'Enter fraction in p/q format (e.g. 1/6 or 1/12).',
        userAnswer: '',
        isCorrect: false,
        skipped: false,
        answered: false,
      });
    }
  }

  return pool;
}

function generateQuestionSet(
  ranges: CategoryRanges,
  totalQuestions: number,
  selectedCategories: CategoryId[]
): QuestionItem[] {
  const pools: Record<string, QuestionItem[]> = {};
  selectedCategories.forEach((cat) => {
    pools[cat] = shuffleArray(buildCategoryPool(cat, ranges));
  });

  const questions: QuestionItem[] = [];
  const catCount = selectedCategories.length;

  for (let i = 0; i < totalQuestions; i++) {
    const cat = selectedCategories[i % catCount];
    let catPool = pools[cat];
    if (!catPool || catPool.length === 0) {
      pools[cat] = shuffleArray(buildCategoryPool(cat, ranges));
      catPool = pools[cat];
    }
    const picked = { ...catPool.pop()! };
    picked.id = `q_${i}_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    picked.userAnswer = '';
    picked.isCorrect = false;
    picked.skipped = false;
    picked.answered = false;
    questions.push(picked);
  }

  return shuffleArray(questions);
}

function evaluateUserAnswer(rawInput: string, question: QuestionItem): boolean {
  const cleaned = rawInput.trim();
  if (!cleaned) return false;

  if (question.expectedType === 'integer') {
    const normalized = cleaned.replace(/,/g, '');
    if (!/^-?\d+$/.test(normalized)) return false;
    return parseInt(normalized, 10) === question.exactValue;
  }

  if (question.expectedType === 'percentage') {
    const noPct = cleaned.replace(/%/g, '').trim();
    const mixedMatch = noPct.match(/^(\d+)\s+(\d+)\s*\/\s*(\d+)$/);
    if (mixedMatch) {
      const whole = parseInt(mixedMatch[1], 10);
      const num = parseInt(mixedMatch[2], 10);
      const den = parseInt(mixedMatch[3], 10);
      if (den !== 0 && question.exactValue !== undefined) {
        const val = whole + num / den;
        return Math.abs(val - question.exactValue) <= 0.06;
      }
    }
    const simpleFracMatch = noPct.match(/^(\d+)\s*\/\s*(\d+)$/);
    if (simpleFracMatch) {
      const num = parseInt(simpleFracMatch[1], 10);
      const den = parseInt(simpleFracMatch[2], 10);
      if (den !== 0 && question.exactValue !== undefined) {
        const val = num / den;
        return Math.abs(val - question.exactValue) <= 0.06;
      }
    }
    const parsed = parseFloat(noPct);
    if (isNaN(parsed) || question.exactValue === undefined) return false;
    return Math.abs(parsed - question.exactValue) <= 0.06;
  }

  if (question.expectedType === 'fraction') {
    const fracMatch = cleaned.match(/^(\d+)\s*\/\s*(\d+)$/);
    if (!fracMatch) return false;
    const num = parseInt(fracMatch[1], 10);
    const den = parseInt(fracMatch[2], 10);
    if (den === 0) return false;
    const g = gcd(num, den);
    return num / g === question.numerator && den / g === question.denominator;
  }

  return false;
}

function formatDuration(totalSec: number): string {
  const mins = Math.floor(totalSec / 60);
  const secs = totalSec % 60;
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

// ==========================================
// MAIN ANDROID APPLICATION COMPONENT
// ==========================================
export default function App() {
  // Theme & Navigation State
  const [darkMode, setDarkMode] = useState<boolean>(true);
  const [activeTab, setActiveTab] = useState<'drill' | 'history' | 'profile'>('drill');
  const [screen, setScreen] = useState<'setup' | 'quiz' | 'review'>('setup');

  // Database State (Profiles & Attempts)
  const [profiles, setProfiles] = useState<UserProfile[]>([]);
  const [activeProfileId, setActiveProfileId] = useState<string | null>(null);
  const [attempts, setAttempts] = useState<QuizAttempt[]>([]);
  const [isDbLoaded, setIsDbLoaded] = useState<boolean>(false);

  // Profile Creation / Onboarding Modal State
  const [newProfileName, setNewProfileName] = useState<string>('');
  const [profileError, setProfileError] = useState<string>('');
  const [showCreateProfileModal, setShowCreateProfileModal] = useState<boolean>(false);

  // Setup Configuration State
  const [selectedCategories, setSelectedCategories] = useState<CategoryId[]>([
    'multiplication',
    'squares',
    'cubes',
    'perc_frac',
  ]);
  const [multFrom, setMultFrom] = useState<string>('11');
  const [multTo, setMultTo] = useState<string>('20');
  const [multM, setMultM] = useState<string>('10');
  const [sqFrom, setSqFrom] = useState<string>('11');
  const [sqTo, setSqTo] = useState<string>('30');
  const [cubeFrom, setCubeFrom] = useState<string>('1');
  const [cubeTo, setCubeTo] = useState<string>('15');
  const [pfFrom, setPfFrom] = useState<string>('2');
  const [pfTo, setPfTo] = useState<string>('20');
  const [totalQuestionsInput, setTotalQuestionsInput] = useState<string>('20');
  const [setupError, setSetupError] = useState<string>('');

  // Active Quiz State
  const [quizModeLabel, setQuizModeLabel] = useState<string>('Standard Drill');
  const [parentAttemptId, setParentAttemptId] = useState<string | undefined>(undefined);
  const [activeRanges, setActiveRanges] = useState<CategoryRanges>({
    multiplication: { from: 11, to: 20, m: 10 },
    squares: { from: 11, to: 30 },
    cubes: { from: 1, to: 15 },
    perc_frac: { from: 2, to: 20 },
  });
  const [questions, setQuestions] = useState<QuestionItem[]>([]);
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [answerInput, setAnswerInput] = useState<string>('');
  const [isSubmitted, setIsSubmitted] = useState<boolean>(false);
  const [correctCount, setCorrectCount] = useState<number>(0);
  const [wrongCount, setWrongCount] = useState<number>(0);
  const [elapsedSeconds, setElapsedSeconds] = useState<number>(0);
  const [logFilter, setLogFilter] = useState<'all' | 'wrong' | 'correct'>('all');
  const [viewingAttempt, setViewingAttempt] = useState<QuizAttempt | null>(null);

  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const startTimeRef = useRef<number>(0);

  // ==========================================
  // LOAD DEVICE LOCAL STORAGE ON STARTUP
  // ==========================================
  useEffect(() => {
    async function loadDatabase() {
      try {
        const [storedProfiles, storedActiveId, storedAttempts, storedTheme] = await Promise.all([
          AsyncStorage.getItem(DB_KEYS.PROFILES),
          AsyncStorage.getItem(DB_KEYS.ACTIVE_PROFILE_ID),
          AsyncStorage.getItem(DB_KEYS.ATTEMPTS),
          AsyncStorage.getItem(DB_KEYS.THEME),
        ]);

        const parsedProfiles: UserProfile[] = storedProfiles ? JSON.parse(storedProfiles) : [];
        const parsedAttempts: QuizAttempt[] = storedAttempts ? JSON.parse(storedAttempts) : [];

        setProfiles(parsedProfiles);
        setAttempts(parsedAttempts);
        if (storedTheme !== null) {
          setDarkMode(storedTheme === 'dark');
        }

        if (parsedProfiles.length > 0) {
          const validActive = parsedProfiles.find((p) => p.id === storedActiveId);
          setActiveProfileId(validActive ? validActive.id : parsedProfiles[0].id);
        } else {
          setShowCreateProfileModal(true);
        }
      } catch (err) {
        console.warn('Error loading local storage database:', err);
      } finally {
        setIsDbLoaded(true);
      }
    }
    loadDatabase();
    return () => stopTimer();
  }, []);

  // Save helper functions
  const saveProfilesToDb = async (updatedProfiles: UserProfile[], newActiveId: string | null) => {
    setProfiles(updatedProfiles);
    setActiveProfileId(newActiveId);
    try {
      await AsyncStorage.setItem(DB_KEYS.PROFILES, JSON.stringify(updatedProfiles));
      if (newActiveId) {
        await AsyncStorage.setItem(DB_KEYS.ACTIVE_PROFILE_ID, newActiveId);
      } else {
        await AsyncStorage.removeItem(DB_KEYS.ACTIVE_PROFILE_ID);
      }
    } catch (e) {
      console.warn('Failed to save profiles:', e);
    }
  };

  const saveAttemptsToDb = async (updatedAttempts: QuizAttempt[]) => {
    setAttempts(updatedAttempts);
    try {
      await AsyncStorage.setItem(DB_KEYS.ATTEMPTS, JSON.stringify(updatedAttempts));
    } catch (e) {
      console.warn('Failed to save attempts:', e);
    }
  };

  const toggleTheme = async () => {
    const next = !darkMode;
    setDarkMode(next);
    try {
      await AsyncStorage.setItem(DB_KEYS.THEME, next ? 'dark' : 'light');
    } catch (e) {
      console.warn(e);
    }
  };

  // ==========================================
  // PROFILE MANAGEMENT
  // ==========================================
  const activeProfile = profiles.find((p) => p.id === activeProfileId) || null;
  const profileAttempts = attempts.filter((a) => a.profileId === activeProfileId);

  const handleCreateProfile = async () => {
    const trimmed = newProfileName.trim();
    if (!trimmed) {
      setProfileError('Please enter your name to create a profile.');
      return;
    }
    const newProfile: UserProfile = {
      id: `prof_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      name: trimmed,
      avatarColor: AVATAR_COLORS[profiles.length % AVATAR_COLORS.length],
      createdAt: new Date().toISOString(),
    };
    const updated = [...profiles, newProfile];
    await saveProfilesToDb(updated, newProfile.id);
    setNewProfileName('');
    setProfileError('');
    setShowCreateProfileModal(false);
  };

  const handleSwitchProfile = async (profileId: string) => {
    setActiveProfileId(profileId);
    try {
      await AsyncStorage.setItem(DB_KEYS.ACTIVE_PROFILE_ID, profileId);
    } catch (e) {
      console.warn(e);
    }
  };

  const handleDeleteProfile = async (profileId: string) => {
    const remainingProfiles = profiles.filter((p) => p.id !== profileId);
    const remainingAttempts = attempts.filter((a) => a.profileId !== profileId);
    const nextActive = remainingProfiles.length > 0 ? remainingProfiles[0].id : null;
    await saveProfilesToDb(remainingProfiles, nextActive);
    await saveAttemptsToDb(remainingAttempts);
    if (!nextActive) {
      setShowCreateProfileModal(true);
    }
  };

  // ==========================================
  // TIMER LOGIC
  // ==========================================
  const startTimer = () => {
    stopTimer();
    startTimeRef.current = Date.now();
    setElapsedSeconds(0);
    timerRef.current = setInterval(() => {
      setElapsedSeconds(Math.floor((Date.now() - startTimeRef.current) / 1000));
    }, 500);
  };

  const stopTimer = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  };

  // ==========================================
  // QUIZ LAUNCH & REATTEMPT WORKFLOWS
  // ==========================================
  const toggleCategory = (cat: CategoryId) => {
    setSetupError('');
    setSelectedCategories((prev) =>
      prev.includes(cat) ? prev.filter((c) => c !== cat) : [...prev, cat]
    );
  };

  const handleStartStandardQuiz = () => {
    if (!activeProfile) {
      setShowCreateProfileModal(true);
      return;
    }
    setSetupError('');
    if (selectedCategories.length === 0) {
      setSetupError('Please select at least one category to start the mock drill.');
      return;
    }

    const parsedRanges: CategoryRanges = {
      multiplication: {
        from: parseInt(multFrom, 10),
        to: parseInt(multTo, 10),
        m: parseInt(multM, 10),
      },
      squares: { from: parseInt(sqFrom, 10), to: parseInt(sqTo, 10) },
      cubes: { from: parseInt(cubeFrom, 10), to: parseInt(cubeTo, 10) },
      perc_frac: { from: parseInt(pfFrom, 10), to: parseInt(pfTo, 10) },
    };

    if (selectedCategories.includes('multiplication')) {
      const { from, to, m } = parsedRanges.multiplication;
      if (isNaN(from) || isNaN(to) || from < 1 || to > 500 || from > to) {
        setSetupError('Multiplication Table: Enter valid From/To range (1–500, From ≤ To).');
        return;
      }
      if (isNaN(m) || m < 2 || m > 200) {
        setSetupError('Multiplication Table: Enter valid Multiply up to (m) (2–200).');
        return;
      }
    }
    if (selectedCategories.includes('squares')) {
      const { from, to } = parsedRanges.squares;
      if (isNaN(from) || isNaN(to) || from < 1 || to > 500 || from > to) {
        setSetupError('Squares: Enter valid From/To range (1–500, From ≤ To).');
        return;
      }
    }
    if (selectedCategories.includes('cubes')) {
      const { from, to } = parsedRanges.cubes;
      if (isNaN(from) || isNaN(to) || from < 1 || to > 200 || from > to) {
        setSetupError('Cubes: Enter valid From/To range (1–200, From ≤ To).');
        return;
      }
    }
    if (selectedCategories.includes('perc_frac')) {
      const { from, to } = parsedRanges.perc_frac;
      if (isNaN(from) || isNaN(to) || from < 2 || to > 200 || from > to) {
        setSetupError('Percentage ↔ Fraction: Enter valid From/To range (2–200, From ≤ To).');
        return;
      }
    }

    const totalQ = parseInt(totalQuestionsInput, 10);
    if (isNaN(totalQ) || totalQ < 1 || totalQ > 300) {
      setSetupError('Please enter a valid Total Questions count (1–300).');
      return;
    }

    const generated = generateQuestionSet(parsedRanges, totalQ, selectedCategories);
    launchQuizSession(generated, parsedRanges, selectedCategories, 'Standard Drill', undefined);
  };

  // Reattempt Option 1: Reattempt Exact Same Questions from a saved attempt
  const handleReattemptExactQuestions = (attempt: QuizAttempt) => {
    const resetQuestions: QuestionItem[] = shuffleArray(
      attempt.questions.map((q, idx) => ({
        ...q,
        id: `re_exact_${idx}_${Date.now()}`,
        userAnswer: '',
        isCorrect: false,
        skipped: false,
        answered: false,
      }))
    );
    launchQuizSession(
      resetQuestions,
      attempt.ranges,
      attempt.selectedCategories,
      'Reattempt (Exact Questions)',
      attempt.id
    );
  };

  // Reattempt Option 2: Reattempt Only Wrong / Skipped Questions from a saved attempt
  const handleReattemptWrongOnly = (attempt: QuizAttempt) => {
    const missed = attempt.questions.filter((q) => !q.isCorrect);
    if (missed.length === 0) return;
    const resetQuestions: QuestionItem[] = shuffleArray(
      missed.map((q, idx) => ({
        ...q,
        id: `re_wrong_${idx}_${Date.now()}`,
        userAnswer: '',
        isCorrect: false,
        skipped: false,
        answered: false,
      }))
    );
    launchQuizSession(
      resetQuestions,
      attempt.ranges,
      attempt.selectedCategories,
      'Reattempt (Wrong/Skipped Only)',
      attempt.id
    );
  };

  // Reattempt Option 3: Reattempt with Same Settings (Freshly Generated Questions)
  const handleReattemptSameConfig = (attempt: QuizAttempt) => {
    const freshQuestions = generateQuestionSet(
      attempt.ranges,
      attempt.totalQuestions,
      attempt.selectedCategories
    );
    launchQuizSession(
      freshQuestions,
      attempt.ranges,
      attempt.selectedCategories,
      'Reattempt (Same Config)',
      attempt.id
    );
  };

  const launchQuizSession = (
    qList: QuestionItem[],
    rangesToUse: CategoryRanges,
    catsToUse: CategoryId[],
    mode: string,
    parentId?: string
  ) => {
    setActiveRanges(rangesToUse);
    setSelectedCategories(catsToUse);
    setQuizModeLabel(mode);
    setParentAttemptId(parentId);
    setQuestions(qList);
    setCurrentIndex(0);
    setAnswerInput('');
    setIsSubmitted(false);
    setCorrectCount(0);
    setWrongCount(0);
    setViewingAttempt(null);
    setActiveTab('drill');
    setScreen('quiz');
    startTimer();
  };

  // ==========================================
  // QUESTION SUBMISSION & GRADING
  // ==========================================
  const handleSubmitAnswer = () => {
    if (isSubmitted) {
      handleNextQuestion();
      return;
    }
    const raw = answerInput.trim();
    if (!raw) {
      if (Platform.OS !== 'web') Vibration.vibrate(50);
      return;
    }
    processSubmission(raw, false);
  };

  const handleSkipQuestion = () => {
    if (isSubmitted) return;
    processSubmission('(Skipped)', true);
  };

  const processSubmission = (userRawText: string, wasSkipped: boolean) => {
    const currentQ = questions[currentIndex];
    const correct = !wasSkipped && evaluateUserAnswer(userRawText, currentQ);

    const updatedQ: QuestionItem = {
      ...currentQ,
      userAnswer: userRawText,
      isCorrect: correct,
      skipped: wasSkipped,
      answered: true,
    };

    const nextQuestions = [...questions];
    nextQuestions[currentIndex] = updatedQ;
    setQuestions(nextQuestions);
    setIsSubmitted(true);

    if (correct) {
      setCorrectCount((c) => c + 1);
    } else {
      setWrongCount((w) => w + 1);
      if (Platform.OS !== 'web') Vibration.vibrate(80);
    }
  };

  const handleNextQuestion = () => {
    if (!isSubmitted) return;
    if (currentIndex + 1 < questions.length) {
      setCurrentIndex((i) => i + 1);
      setAnswerInput('');
      setIsSubmitted(false);
    } else {
      finishAndSaveAttempt(questions);
    }
  };

  const finishAndSaveAttempt = async (finalQuestions: QuestionItem[]) => {
    stopTimer();
    const finalElapsed = Math.max(
      1,
      Math.floor((Date.now() - startTimeRef.current) / 1000) || elapsedSeconds
    );
    const answeredList = finalQuestions.filter((q) => q.answered);
    const attemptedCount = answeredList.length;
    const corr = answeredList.filter((q) => q.isCorrect).length;
    const skip = answeredList.filter((q) => q.skipped).length;
    const wrng = attemptedCount - corr;
    const acc = attemptedCount > 0 ? Math.round((corr / attemptedCount) * 100) : 0;

    if (activeProfile && attemptedCount > 0) {
      const newAttempt: QuizAttempt = {
        id: `att_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
        profileId: activeProfile.id,
        profileName: activeProfile.name,
        timestamp: new Date().toISOString(),
        modeLabel: quizModeLabel,
        parentAttemptId,
        ranges: activeRanges,
        selectedCategories,
        totalQuestions: finalQuestions.length,
        attemptedCount,
        correctCount: corr,
        wrongCount: wrng,
        skippedCount: skip,
        accuracy: acc,
        elapsedSeconds: finalElapsed,
        questions: finalQuestions,
      };
      const updatedAttempts = [newAttempt, ...attempts];
      await saveAttemptsToDb(updatedAttempts);
      setViewingAttempt(newAttempt);
    } else {
      setViewingAttempt(null);
    }

    setLogFilter('all');
    setScreen('review');
  };

  const currentQuestion = questions[currentIndex];
  const themeStyles = getThemeStyles(darkMode);

  if (!isDbLoaded) {
    return (
      <SafeAreaView style={[styles.container, themeStyles.bg]}>
        <View style={styles.centerBox}>
          <Text style={[styles.titleText, themeStyles.text]}>Loading Speed Math Database...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={[styles.container, themeStyles.bg]}>
      <StatusBar barStyle={darkMode ? 'light-content' : 'dark-content'} />

      {/* TOP HEADER BAR */}
      <View style={[styles.header, themeStyles.card, themeStyles.border]}>
        <View style={styles.headerLeft}>
          <View style={styles.logoBadge}>
            <Text style={styles.logoSymbol}>∑</Text>
          </View>
          <View>
            <Text style={[styles.headerTitle, themeStyles.text]}>Speed Math Mock Drill</Text>
            <Text style={styles.headerSubtitle}>Dev: Ayan Dhali</Text>
          </View>
        </View>

        <View style={styles.headerRight}>
          {activeProfile && (
            <TouchableOpacity
              style={styles.profilePill}
              onPress={() => setActiveTab('profile')}
            >
              <View
                style={[styles.avatarDot, { backgroundColor: activeProfile.avatarColor }]}
              >
                <Text style={styles.avatarInitial}>
                  {activeProfile.name.charAt(0).toUpperCase()}
                </Text>
              </View>
              <Text style={[styles.profilePillText, themeStyles.text]} numberOfLines={1}>
                {activeProfile.name}
              </Text>
            </TouchableOpacity>
          )}
          <TouchableOpacity style={styles.themeBtn} onPress={toggleTheme}>
            <Text style={{ fontSize: 16 }}>{darkMode ? '☀️' : '🌙'}</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* MAIN CONTENT AREA */}
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView contentContainerStyle={styles.scrollContent}>
          {/* TAB 1: DRILL (SETUP / QUIZ / REVIEW) */}
          {activeTab === 'drill' && screen === 'setup' && (
            <View style={[styles.sectionCard, themeStyles.card, themeStyles.border]}>
              <Text style={styles.badgePill}>⚡ CUSTOM RANGE MOCK DRILL</Text>
              <Text style={[styles.titleText, themeStyles.text]}>
                Configure Categories & Ranges
              </Text>
              <Text style={[styles.subtitleText, themeStyles.subText]}>
                Attempts are automatically stored on your device under profile:{' '}
                <Text style={{ fontWeight: '700', color: '#6366f1' }}>
                  {activeProfile ? activeProfile.name : 'No Profile'}
                </Text>
              </Text>

              {/* Category 1: Multiplication */}
              <View style={[styles.catBox, themeStyles.border]}>
                <TouchableOpacity
                  style={styles.catHeader}
                  onPress={() => toggleCategory('multiplication')}
                >
                  <Text style={styles.checkboxIcon}>
                    {selectedCategories.includes('multiplication') ? '☑️' : '⬜'}
                  </Text>
                  <Text style={[styles.catTitle, themeStyles.text]}>Multiplication Table</Text>
                </TouchableOpacity>
                <View style={styles.rangeRow}>
                  <View style={styles.rangeCol}>
                    <Text style={styles.inputLabel}>From</Text>
                    <TextInput
                      style={[styles.numInput, themeStyles.input]}
                      keyboardType="numeric"
                      value={multFrom}
                      onChangeText={setMultFrom}
                    />
                  </View>
                  <View style={styles.rangeCol}>
                    <Text style={styles.inputLabel}>To</Text>
                    <TextInput
                      style={[styles.numInput, themeStyles.input]}
                      keyboardType="numeric"
                      value={multTo}
                      onChangeText={setMultTo}
                    />
                  </View>
                  <View style={styles.rangeCol}>
                    <Text style={styles.inputLabel}>Up to (×m)</Text>
                    <TextInput
                      style={[styles.numInput, themeStyles.input]}
                      keyboardType="numeric"
                      value={multM}
                      onChangeText={setMultM}
                    />
                  </View>
                </View>
              </View>

              {/* Category 2: Squares */}
              <View style={[styles.catBox, themeStyles.border]}>
                <TouchableOpacity
                  style={styles.catHeader}
                  onPress={() => toggleCategory('squares')}
                >
                  <Text style={styles.checkboxIcon}>
                    {selectedCategories.includes('squares') ? '☑️' : '⬜'}
                  </Text>
                  <Text style={[styles.catTitle, themeStyles.text]}>Squares (n²)</Text>
                </TouchableOpacity>
                <View style={styles.rangeRow}>
                  <View style={styles.rangeCol}>
                    <Text style={styles.inputLabel}>From</Text>
                    <TextInput
                      style={[styles.numInput, themeStyles.input]}
                      keyboardType="numeric"
                      value={sqFrom}
                      onChangeText={setSqFrom}
                    />
                  </View>
                  <View style={styles.rangeCol}>
                    <Text style={styles.inputLabel}>To</Text>
                    <TextInput
                      style={[styles.numInput, themeStyles.input]}
                      keyboardType="numeric"
                      value={sqTo}
                      onChangeText={setSqTo}
                    />
                  </View>
                </View>
              </View>

              {/* Category 3: Cubes */}
              <View style={[styles.catBox, themeStyles.border]}>
                <TouchableOpacity
                  style={styles.catHeader}
                  onPress={() => toggleCategory('cubes')}
                >
                  <Text style={styles.checkboxIcon}>
                    {selectedCategories.includes('cubes') ? '☑️' : '⬜'}
                  </Text>
                  <Text style={[styles.catTitle, themeStyles.text]}>Cubes (n³)</Text>
                </TouchableOpacity>
                <View style={styles.rangeRow}>
                  <View style={styles.rangeCol}>
                    <Text style={styles.inputLabel}>From</Text>
                    <TextInput
                      style={[styles.numInput, themeStyles.input]}
                      keyboardType="numeric"
                      value={cubeFrom}
                      onChangeText={setCubeFrom}
                    />
                  </View>
                  <View style={styles.rangeCol}>
                    <Text style={styles.inputLabel}>To</Text>
                    <TextInput
                      style={[styles.numInput, themeStyles.input]}
                      keyboardType="numeric"
                      value={cubeTo}
                      onChangeText={setCubeTo}
                    />
                  </View>
                </View>
              </View>

              {/* Category 4: Percentage <-> Fraction */}
              <View style={[styles.catBox, themeStyles.border]}>
                <TouchableOpacity
                  style={styles.catHeader}
                  onPress={() => toggleCategory('perc_frac')}
                >
                  <Text style={styles.checkboxIcon}>
                    {selectedCategories.includes('perc_frac') ? '☑️' : '⬜'}
                  </Text>
                  <Text style={[styles.catTitle, themeStyles.text]}>Percentage ↔ Fraction</Text>
                </TouchableOpacity>
                <View style={styles.rangeRow}>
                  <View style={styles.rangeCol}>
                    <Text style={styles.inputLabel}>From Denom (n)</Text>
                    <TextInput
                      style={[styles.numInput, themeStyles.input]}
                      keyboardType="numeric"
                      value={pfFrom}
                      onChangeText={setPfFrom}
                    />
                  </View>
                  <View style={styles.rangeCol}>
                    <Text style={styles.inputLabel}>To Denom (n)</Text>
                    <TextInput
                      style={[styles.numInput, themeStyles.input]}
                      keyboardType="numeric"
                      value={pfTo}
                      onChangeText={setPfTo}
                    />
                  </View>
                </View>
              </View>

              {/* Total Questions */}
              <View style={[styles.catBox, themeStyles.border]}>
                <Text style={[styles.catTitle, themeStyles.text]}>Total Questions (1–300)</Text>
                <View style={[styles.rangeRow, { marginTop: 8 }]}>
                  <TextInput
                    style={[styles.numInput, themeStyles.input, { flex: 1 }]}
                    keyboardType="numeric"
                    value={totalQuestionsInput}
                    onChangeText={setTotalQuestionsInput}
                  />
                  {['10', '20', '30', '50'].map((preset) => (
                    <TouchableOpacity
                      key={preset}
                      style={[
                        styles.presetBtn,
                        totalQuestionsInput === preset && styles.presetBtnActive,
                      ]}
                      onPress={() => setTotalQuestionsInput(preset)}
                    >
                      <Text
                        style={[
                          styles.presetBtnText,
                          totalQuestionsInput === preset && { color: '#fff' },
                        ]}
                      >
                        {preset}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>

              {setupError ? <Text style={styles.errorText}>{setupError}</Text> : null}

              <TouchableOpacity style={styles.primaryCtaBtn} onPress={handleStartStandardQuiz}>
                <Text style={styles.primaryCtaText}>Start Mock Drill →</Text>
              </TouchableOpacity>
            </View>
          )}

          {/* QUIZ SCREEN */}
          {activeTab === 'drill' && screen === 'quiz' && currentQuestion && (
            <View style={[styles.sectionCard, themeStyles.card, themeStyles.border]}>
              <View style={styles.quizTopRow}>
                <Text style={[styles.qCounterText, themeStyles.text]}>
                  Q {currentIndex + 1} / {questions.length}
                </Text>
                <Text style={styles.modeTag}>{quizModeLabel}</Text>
                <Text style={[styles.timerText, themeStyles.text]}>
                  ⏱ {formatDuration(elapsedSeconds)}
                </Text>
              </View>

              <View style={styles.scoreRow}>
                <Text style={styles.correctPill}>✓ Correct: {correctCount}</Text>
                <Text style={styles.wrongPill}>✗ Wrong: {wrongCount}</Text>
                <TouchableOpacity onPress={() => finishAndSaveAttempt(questions)}>
                  <Text style={styles.endEarlyText}>End & Save →</Text>
                </TouchableOpacity>
              </View>

              <View style={styles.promptBox}>
                <Text style={styles.subPromptText}>{currentQuestion.subPrompt}</Text>
                <Text style={[styles.mainPromptText, themeStyles.text]}>
                  {currentQuestion.prompt}
                </Text>
              </View>

              <TextInput
                style={[styles.answerInputBox, themeStyles.input]}
                value={answerInput}
                onChangeText={setAnswerInput}
                editable={!isSubmitted}
                placeholder="Type your answer..."
                placeholderTextColor="#94a3b8"
                onSubmitEditing={handleSubmitAnswer}
              />
              <Text style={styles.hintText}>{currentQuestion.hint}</Text>

              {isSubmitted && (
                <View
                  style={[
                    styles.feedbackBox,
                    currentQuestion.isCorrect ? styles.feedbackCorrect : styles.feedbackWrong,
                  ]}
                >
                  <Text style={styles.feedbackTitle}>
                    {currentQuestion.isCorrect
                      ? '✓ Correct! Well done.'
                      : `✗ ${currentQuestion.skipped ? 'Skipped!' : 'Wrong!'} Answer: ${
                          currentQuestion.displayAnswer
                        }`}
                  </Text>
                  <Text style={styles.feedbackDetail}>{currentQuestion.explanation}</Text>
                </View>
              )}

              <View style={styles.actionBtnRow}>
                {!isSubmitted ? (
                  <>
                    <TouchableOpacity
                      style={[styles.primaryCtaBtn, { flex: 1 }]}
                      onPress={handleSubmitAnswer}
                    >
                      <Text style={styles.primaryCtaText}>Submit Answer</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.skipBtn} onPress={handleSkipQuestion}>
                      <Text style={styles.skipBtnText}>Don't Know</Text>
                    </TouchableOpacity>
                  </>
                ) : (
                  <TouchableOpacity
                    style={[styles.primaryCtaBtn, { flex: 1, backgroundColor: '#059669' }]}
                    onPress={handleNextQuestion}
                  >
                    <Text style={styles.primaryCtaText}>
                      {currentIndex + 1 === questions.length
                        ? 'Finish & View Report →'
                        : 'Next Question →'}
                    </Text>
                  </TouchableOpacity>
                )}
              </View>
            </View>
          )}

          {/* REVIEW SCREEN */}
          {activeTab === 'drill' && screen === 'review' && (
            <View style={[styles.sectionCard, themeStyles.card, themeStyles.border]}>
              <Text style={styles.badgePill}>📊 DRILL SAVED TO PROFILE</Text>
              <Text style={[styles.titleText, themeStyles.text]}>Performance Report</Text>
              {viewingAttempt && (
                <>
                  <View style={styles.statsGrid}>
                    <View style={styles.statCard}>
                      <Text style={styles.statLabel}>Attempted</Text>
                      <Text style={[styles.statVal, themeStyles.text]}>
                        {viewingAttempt.attemptedCount}
                      </Text>
                    </View>
                    <View style={styles.statCard}>
                      <Text style={styles.statLabel}>Correct</Text>
                      <Text style={[styles.statVal, { color: '#10b981' }]}>
                        {viewingAttempt.correctCount}
                      </Text>
                    </View>
                    <View style={styles.statCard}>
                      <Text style={styles.statLabel}>Wrong</Text>
                      <Text style={[styles.statVal, { color: '#f43f5e' }]}>
                        {viewingAttempt.wrongCount}
                      </Text>
                    </View>
                    <View style={styles.statCard}>
                      <Text style={styles.statLabel}>Accuracy</Text>
                      <Text style={[styles.statVal, { color: '#6366f1' }]}>
                        {viewingAttempt.accuracy}%
                      </Text>
                    </View>
                  </View>

                  {/* REATTEMPT OPTIONS */}
                  <Text style={[styles.catTitle, themeStyles.text, { marginTop: 14 }]}>
                    Reattempt Options
                  </Text>
                  <View style={{ gap: 8, marginTop: 8 }}>
                    <TouchableOpacity
                      style={styles.reattemptBtn}
                      onPress={() => handleReattemptExactQuestions(viewingAttempt)}
                    >
                      <Text style={styles.reattemptBtnText}>
                        🔁 Reattempt Exact Same Questions ({viewingAttempt.questions.length} Qs)
                      </Text>
                    </TouchableOpacity>
                    {viewingAttempt.wrongCount > 0 && (
                      <TouchableOpacity
                        style={[styles.reattemptBtn, { backgroundColor: '#e11d48' }]}
                        onPress={() => handleReattemptWrongOnly(viewingAttempt)}
                      >
                        <Text style={styles.reattemptBtnText}>
                          🎯 Reattempt Wrong / Skipped Only ({viewingAttempt.wrongCount} Qs)
                        </Text>
                      </TouchableOpacity>
                    )}
                    <TouchableOpacity
                      style={[styles.reattemptBtn, { backgroundColor: '#0891b2' }]}
                      onPress={() => handleReattemptSameConfig(viewingAttempt)}
                    >
                      <Text style={styles.reattemptBtnText}>
                        ⚡ New Drill with Same Settings
                      </Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={styles.secondaryBtn}
                      onPress={() => setScreen('setup')}
                    >
                      <Text style={[styles.secondaryBtnText, themeStyles.text]}>
                        ⚙ Back to Range Setup
                      </Text>
                    </TouchableOpacity>
                  </View>
                </>
              )}
            </View>
          )}

          {/* TAB 2: ATTEMPT HISTORY & REATTEMPT HUB */}
          {activeTab === 'history' && (
            <View style={[styles.sectionCard, themeStyles.card, themeStyles.border]}>
              <Text style={[styles.titleText, themeStyles.text]}>
                Saved Attempts ({activeProfile?.name})
              </Text>
              <Text style={[styles.subtitleText, themeStyles.subText]}>
                Stored locally on device. Select any past attempt to review or reattempt.
              </Text>
              {profileAttempts.length === 0 ? (
                <Text style={[styles.subtitleText, themeStyles.subText, { marginTop: 16 }]}>
                  No attempts recorded for this profile yet. Start a drill to save your first attempt!
                </Text>
              ) : (
                profileAttempts.map((att) => (
                  <View key={att.id} style={[styles.catBox, themeStyles.border]}>
                    <View style={styles.quizTopRow}>
                      <Text style={[styles.catTitle, themeStyles.text]}>
                        {att.accuracy}% Accuracy ({att.correctCount}/{att.attemptedCount})
                      </Text>
                      <Text style={styles.modeTag}>{att.modeLabel}</Text>
                    </View>
                    <Text style={[styles.subtitleText, themeStyles.subText]}>
                      {new Date(att.timestamp).toLocaleString()} • Time:{' '}
                      {formatDuration(att.elapsedSeconds)}
                    </Text>
                    <View style={[styles.rangeRow, { marginTop: 10 }]}>
                      <TouchableOpacity
                        style={[styles.reattemptBtn, { flex: 1 }]}
                        onPress={() => handleReattemptExactQuestions(att)}
                      >
                        <Text style={styles.reattemptBtnText}>🔁 Reattempt Exact</Text>
                      </TouchableOpacity>
                      {att.wrongCount > 0 && (
                        <TouchableOpacity
                          style={[
                            styles.reattemptBtn,
                            { flex: 1, backgroundColor: '#e11d48' },
                          ]}
                          onPress={() => handleReattemptWrongOnly(att)}
                        >
                          <Text style={styles.reattemptBtnText}>
                            🎯 Fix Wrong ({att.wrongCount})
                          </Text>
                        </TouchableOpacity>
                      )}
                    </View>
                  </View>
                ))
              )}
            </View>
          )}

          {/* TAB 3: PROFILE & DEVELOPER CREDIT */}
          {activeTab === 'profile' && (
            <View style={[styles.sectionCard, themeStyles.card, themeStyles.border]}>
              <Text style={[styles.titleText, themeStyles.text]}>User Profiles</Text>
              <Text style={[styles.subtitleText, themeStyles.subText]}>
                Switch profiles or create a new profile. All drill attempts are linked to your active profile.
              </Text>

              {profiles.map((prof) => {
                const isCurrent = prof.id === activeProfileId;
                const count = attempts.filter((a) => a.profileId === prof.id).length;
                return (
                  <TouchableOpacity
                    key={prof.id}
                    style={[
                      styles.catBox,
                      themeStyles.border,
                      isCurrent && { borderColor: '#6366f1', borderWidth: 2 },
                    ]}
                    onPress={() => handleSwitchProfile(prof.id)}
                  >
                    <View style={styles.quizTopRow}>
                      <Text style={[styles.catTitle, themeStyles.text]}>
                        {prof.name} {isCurrent ? '(Active)' : ''}
                      </Text>
                      <Text style={styles.modeTag}>{count} Attempts</Text>
                    </View>
                  </TouchableOpacity>
                );
              })}

              <TouchableOpacity
                style={styles.primaryCtaBtn}
                onPress={() => setShowCreateProfileModal(true)}
              >
                <Text style={styles.primaryCtaText}>+ Create New Profile</Text>
              </TouchableOpacity>

              <View style={[styles.creditCard, themeStyles.border]}>
                <Text style={styles.creditLabel}>APPLICATION DEVELOPER CREDIT</Text>
                <Text style={[styles.creditName, themeStyles.text]}>Ayan Dhali</Text>
                <Text style={[styles.subtitleText, themeStyles.subText]}>
                  Lead Developer & Designer • Speed Math Mock Drill Android App
                </Text>
              </View>
            </View>
          )}
        </ScrollView>
      </KeyboardAvoidingView>

      {/* BOTTOM NAVIGATION BAR */}
      <View style={[styles.bottomNav, themeStyles.card, themeStyles.border]}>
        <TouchableOpacity style={styles.navItem} onPress={() => setActiveTab('drill')}>
          <Text style={[styles.navText, activeTab === 'drill' && styles.navTextActive]}>
            ⚡ Mock Drill
          </Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.navItem} onPress={() => setActiveTab('history')}>
          <Text style={[styles.navText, activeTab === 'history' && styles.navTextActive]}>
            📂 Attempts ({profileAttempts.length})
          </Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.navItem} onPress={() => setActiveTab('profile')}>
          <Text style={[styles.navText, activeTab === 'profile' && styles.navTextActive]}>
            👤 Profile
          </Text>
        </TouchableOpacity>
      </View>

      {/* CREATE PROFILE MODAL */}
      <Modal visible={showCreateProfileModal} transparent animationType="fade">
        <View style={styles.modalBackdrop}>
          <View style={[styles.modalCard, themeStyles.card, themeStyles.border]}>
            <Text style={styles.badgePill}>👤 USER PROFILE SETUP</Text>
            <Text style={[styles.titleText, themeStyles.text]}>What's your name?</Text>
            <Text style={[styles.subtitleText, themeStyles.subText]}>
              Create your profile to store all your Speed Math attempts and reattempt history on this device.
            </Text>
            <TextInput
              style={[styles.numInput, themeStyles.input, { marginTop: 14, fontSize: 16 }]}
              placeholder="Enter your full name..."
              placeholderTextColor="#94a3b8"
              value={newProfileName}
              onChangeText={(val) => {
                setNewProfileName(val);
                setProfileError('');
              }}
              onSubmitEditing={handleCreateProfile}
            />
            {profileError ? <Text style={styles.errorText}>{profileError}</Text> : null}
            <TouchableOpacity style={styles.primaryCtaBtn} onPress={handleCreateProfile}>
              <Text style={styles.primaryCtaText}>Save Profile & Continue</Text>
            </TouchableOpacity>
            {profiles.length > 0 && (
              <TouchableOpacity
                style={[styles.secondaryBtn, { marginTop: 8 }]}
                onPress={() => setShowCreateProfileModal(false)}
              >
                <Text style={[styles.secondaryBtnText, themeStyles.text]}>Cancel</Text>
              </TouchableOpacity>
            )}
            <Text style={[styles.hintText, { marginTop: 14 }]}>
              Developed by Ayan Dhali
            </Text>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const getThemeStyles = (isDark: boolean) =>
  StyleSheet.create({
    bg: { backgroundColor: isDark ? '#020617' : '#f8fafc' },
    card: { backgroundColor: isDark ? '#0f172a' : '#ffffff' },
    text: { color: isDark ? '#f8fafc' : '#0f172a' },
    subText: { color: isDark ? '#94a3b8' : '#64748b' },
    border: { borderColor: isDark ? '#1e293b' : '#e2e8f0' },
    input: {
      backgroundColor: isDark ? '#1e293b' : '#f1f5f9',
      color: isDark ? '#ffffff' : '#0f172a',
      borderColor: isDark ? '#334155' : '#cbd5e1',
    },
  });

const styles = StyleSheet.create({
  container: { flex: 1 },
  centerBox: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
  },
  headerLeft: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  logoBadge: {
    width: 38,
    height: 38,
    borderRadius: 10,
    backgroundColor: '#4f46e5',
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoSymbol: { color: '#fff', fontSize: 18, fontWeight: '800' },
  headerTitle: { fontSize: 16, fontWeight: '800' },
  headerSubtitle: { fontSize: 11, color: '#6366f1', fontWeight: '700' },
  headerRight: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  profilePill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 20,
    backgroundColor: 'rgba(99, 102, 241, 0.12)',
  },
  avatarDot: {
    width: 22,
    height: 22,
    borderRadius: 11,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarInitial: { color: '#fff', fontSize: 11, fontWeight: '800' },
  profilePillText: { fontSize: 12, fontWeight: '700', maxWidth: 90 },
  themeBtn: { padding: 8, borderRadius: 10 },
  scrollContent: { padding: 16, paddingBottom: 36 },
  sectionCard: { borderRadius: 18, padding: 18, borderWidth: 1 },
  badgePill: {
    alignSelf: 'flex-start',
    fontSize: 10,
    fontWeight: '800',
    color: '#6366f1',
    backgroundColor: 'rgba(99, 102, 241, 0.12)',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
    marginBottom: 8,
  },
  titleText: { fontSize: 21, fontWeight: '800' },
  subtitleText: { fontSize: 13, marginTop: 4, lineHeight: 18 },
  catBox: { marginTop: 14, padding: 14, borderRadius: 14, borderWidth: 1 },
  catHeader: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 10 },
  checkboxIcon: { fontSize: 18 },
  catTitle: { fontSize: 15, fontWeight: '700' },
  rangeRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  rangeCol: { flex: 1 },
  inputLabel: { fontSize: 11, color: '#94a3b8', marginBottom: 4, fontWeight: '600' },
  numInput: {
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 8,
    fontSize: 14,
    fontWeight: '700',
  },
  presetBtn: {
    paddingHorizontal: 12,
    paddingVertical: 9,
    borderRadius: 10,
    backgroundColor: '#334155',
  },
  presetBtnActive: { backgroundColor: '#4f46e5' },
  presetBtnText: { fontSize: 12, fontWeight: '700', color: '#cbd5e1' },
  errorText: { color: '#f43f5e', fontSize: 13, fontWeight: '600', marginTop: 10 },
  primaryCtaBtn: {
    marginTop: 16,
    backgroundColor: '#4f46e5',
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
  },
  primaryCtaText: { color: '#ffffff', fontSize: 15, fontWeight: '800' },
  quizTopRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  qCounterText: { fontSize: 16, fontWeight: '800' },
  modeTag: {
    fontSize: 11,
    fontWeight: '700',
    color: '#6366f1',
    backgroundColor: 'rgba(99, 102, 241, 0.14)',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 8,
  },
  timerText: { fontSize: 14, fontWeight: '700' },
  scoreRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 12,
  },
  correctPill: { color: '#10b981', fontWeight: '800', fontSize: 13 },
  wrongPill: { color: '#f43f5e', fontWeight: '800', fontSize: 13 },
  endEarlyText: { color: '#94a3b8', fontSize: 12, fontWeight: '600' },
  promptBox: {
    marginVertical: 18,
    paddingVertical: 26,
    paddingHorizontal: 14,
    borderRadius: 16,
    backgroundColor: 'rgba(99, 102, 241, 0.06)',
    alignItems: 'center',
  },
  subPromptText: { fontSize: 11, color: '#94a3b8', fontWeight: '700', marginBottom: 8 },
  mainPromptText: { fontSize: 32, fontWeight: '800', textAlign: 'center' },
  answerInputBox: {
    borderWidth: 2,
    borderRadius: 14,
    paddingVertical: 14,
    paddingHorizontal: 16,
    fontSize: 24,
    fontWeight: '800',
    textAlign: 'center',
  },
  hintText: { fontSize: 11, color: '#94a3b8', textAlign: 'center', marginTop: 8 },
  feedbackBox: { marginTop: 14, padding: 14, borderRadius: 12, borderWidth: 1 },
  feedbackCorrect: {
    backgroundColor: 'rgba(16, 185, 129, 0.12)',
    borderColor: '#10b981',
  },
  feedbackWrong: {
    backgroundColor: 'rgba(244, 63, 94, 0.12)',
    borderColor: '#f43f5e',
  },
  feedbackTitle: { fontSize: 14, fontWeight: '800', color: '#f8fafc' },
  feedbackDetail: { fontSize: 12, color: '#cbd5e1', marginTop: 4 },
  actionBtnRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  skipBtn: {
    marginTop: 16,
    paddingVertical: 14,
    paddingHorizontal: 16,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#475569',
  },
  skipBtnText: { color: '#94a3b8', fontWeight: '700', fontSize: 13 },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 14 },
  statCard: {
    flex: 1,
    minWidth: '45%',
    padding: 12,
    borderRadius: 12,
    backgroundColor: 'rgba(99, 102, 241, 0.06)',
    alignItems: 'center',
  },
  statLabel: { fontSize: 11, color: '#94a3b8', fontWeight: '700' },
  statVal: { fontSize: 22, fontWeight: '800', marginTop: 4 },
  reattemptBtn: {
    backgroundColor: '#4f46e5',
    paddingVertical: 12,
    paddingHorizontal: 14,
    borderRadius: 12,
    alignItems: 'center',
  },
  reattemptBtnText: { color: '#fff', fontSize: 13, fontWeight: '800' },
  secondaryBtn: {
    paddingVertical: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#475569',
    alignItems: 'center',
  },
  secondaryBtnText: { fontSize: 13, fontWeight: '700' },
  creditCard: {
    marginTop: 24,
    padding: 16,
    borderRadius: 14,
    borderWidth: 1,
    alignItems: 'center',
    backgroundColor: 'rgba(99, 102, 241, 0.06)',
  },
  creditLabel: { fontSize: 10, fontWeight: '800', color: '#6366f1', letterSpacing: 1 },
  creditName: { fontSize: 18, fontWeight: '800', marginTop: 4 },
  bottomNav: {
    flexDirection: 'row',
    borderTopWidth: 1,
    paddingVertical: 12,
    justifyContent: 'space-around',
  },
  navItem: { paddingHorizontal: 12, paddingVertical: 4 },
  navText: { fontSize: 13, fontWeight: '700', color: '#94a3b8' },
  navTextActive: { color: '#6366f1', fontWeight: '800' },
  modalBackdrop: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.75)',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  modalCard: { width: '100%', maxWidth: 400, borderRadius: 20, padding: 22, borderWidth: 1 },
});
