# Speed Math Mock Drill — React Native Android App
**Developed by Ayan Dhali**

A complete React Native (Expo / Android) mobile application converted from the Speed Math Mock Drill HTML software, featuring local device storage (`@react-native-async-storage/async-storage`), a multi-user Profile System, full Attempt History per profile, and 3 flexible Reattempt modes.

---

## Key Features

1. **Profile System with Onboarding**:
   - Prompts the user for their name on first launch to create a profile.
   - Supports creating multiple profiles, switching active profiles at any time, and deleting profiles.
   - Every quiz attempt is automatically saved under the currently active user profile.

2. **Device Local Storage Database (`AsyncStorage`)**:
   - Stores all profiles (`@speedmath_db_profiles_v1`), active profile selection (`@speedmath_db_active_profile_v1`), theme preference (`@speedmath_db_theme_v1`), and complete quiz attempt logs (`@speedmath_db_attempts_v1`) locally on the Android device.
   - Works 100% offline with zero external servers required.

3. **Three Reattempt Modes**:
   - **Reattempt Exact Questions**: Replay the exact same set of questions from any saved attempt to beat your previous score and time.
   - **Reattempt Wrong / Skipped Only**: Practice only the questions you got wrong or skipped in a past attempt.
   - **Reattempt Same Settings (Fresh Questions)**: Launch a new randomized drill using the exact category & range settings from any past attempt.

4. **Custom Range Speed Math Engine**:
   - **Multiplication Table**: Custom `From` and `To` table ranges multiplied up to `m` (with `×10`, `×15`, `×20` quick chips).
   - **Squares ($n^2$)**: Custom `From` and `To` number ranges.
   - **Cubes ($n^3$)**: Custom `From` and `To` number ranges.
   - **Percentage ↔ Fraction ($1/n$)**: Vice-versa conversions supporting decimals, integers, mixed fractions (`16 2/3%`), and simple fractions (`1/6`).

5. **Developer Credit**:
   - Built and credited to **Ayan Dhali** across the app header, profile screen, onboarding modal, and project metadata (`com.ayandhali.speedmathmockdrill`).

---

## How to Run on Android or Build an Installable APK

### Prerequisites
- Install [Node.js (LTS)](https://nodejs.org/) on your computer.

### Option A: Run Instantly on Your Android Phone (via Expo Go)
1. Extract `SpeedMathAndroidApp-ReactNative.zip` and open a terminal in the folder:
   ```bash
   npm install
   npx expo start
   ```
2. Install **Expo Go** from the Google Play Store on your Android device and scan the QR code displayed in the terminal.

### Option B: Build a Standalone Android `.apk` File (via EAS Build)
1. Install the EAS CLI and log in to your free Expo account:
   ```bash
   npm install -g eas-cli
   eas login
   ```
2. Run the APK build command configured in `eas.json`:
   ```bash
   npm run build:apk
   ```
   *(Or run `eas build -p android --profile preview`)*
3. Once the build finishes, EAS provides a direct download link & QR code to install the `.apk` directly on any Android device.

### Option C: Build Locally with Android Studio
1. Generate the native Android `android/` directory and compile the release APK locally:
   ```bash
   npx expo prebuild --platform android
   cd android && ./gradlew assembleRelease
   ```
   Your signed/unsigned APK will be generated in `android/app/build/outputs/apk/release/`.
